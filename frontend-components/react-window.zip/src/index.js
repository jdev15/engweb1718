import 'window.css';

import React from 'react';
import ReactDOM from 'react-dom';
import Window from './Window.js';

ReactDOM.render(<Window title='Window' />, document.getElementById('root'));

import React from 'react';
import ReactDOM from 'react-dom';
import TopBar from './TopBar.js';
import './topbar.css';

ReactDOM.render(<TopBar title='TopBar' />, document.getElementById('root'));
import React from 'react';
import ReactDOM from 'react-dom';
import TabelaAtivos from './TabelaAtivos.js';
import './tabela.css';

ReactDOM.render(<TabelaAtivos title='TabelaAtivos' />, document.getElementById('root'));

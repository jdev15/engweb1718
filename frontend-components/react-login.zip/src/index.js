import 'login.css';

import React from 'react';
import ReactDOM from 'react-dom';
import Login from './Login.js';

ReactDOM.render(<Login title='Login' />, document.getElementById('root'));
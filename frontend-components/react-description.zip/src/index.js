import 'description.css';
import 'react-tabs/style/react-tabs.css';
import React from 'react';
import ReactDOM from 'react-dom';
import Description from './Description.js';

ReactDOM.render(<Description title='Description' />, document.getElementById('root'));
import 'signin.css';

import React from 'react';
import ReactDOM from 'react-dom';
import SignIn from './SignIn.js';

ReactDOM.render(<SignIn title='Sign In' />, document.getElementById('root'));